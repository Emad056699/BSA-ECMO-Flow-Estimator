// Build the library from materials.json
const $ = (sel)=>document.querySelector(sel);
const grid = $("#grid");
const catSel = $("#category");
const langSel = $("#language");
const search = $("#search");
const empty = $("#empty");
const yearSpan = document.getElementById("year");
yearSpan.textContent = new Date().getFullYear();

let materials = [];

function badge(text){ const b=document.createElement('span'); b.className='badge'; b.textContent=text; return b; }

function fmtSize(bytes){
  if(!bytes) return '';
  const units = ['B','KB','MB','GB'];
  let i=0, n=bytes;
  while(n>=1024 && i<units.length-1){ n/=1024; i++; }
  return `${n.toFixed( (i===0)?0:1 )} ${units[i]}`;
}

function render(){
  const q = search.value.trim().toLowerCase();
  const cat = catSel.value;
  const lang = langSel.value;

  const filtered = materials.filter(m=>{
    const okCat = !cat || m.category===cat;
    const okLang = !lang || m.language===lang;
    const hay = (m.title+' '+(m.description||'')+' '+(m.tags||[]).join(' ')).toLowerCase();
    const okSearch = !q || hay.includes(q);
    return okCat && okLang && okSearch;
  });

  grid.innerHTML = '';
  filtered.forEach(m=>{
    const card = document.createElement('div');
    card.className = 'card';

    const topRow = document.createElement('div');
    topRow.className = 'row';
    const left = document.createElement('div');
    left.appendChild(badge(m.category));
    if(m.language){ const lb = badge(m.language.toUpperCase()); lb.style.background='#eef2ff'; left.appendChild(document.createTextNode(' ')); left.appendChild(lb); }
    topRow.appendChild(left);
    const right = document.createElement('div');
    right.className = 'meta';
    right.textContent = (m.format? m.format.toUpperCase()+' • ' : '') + (m.size? fmtSize(m.size):'');
    topRow.appendChild(right);

    const title = document.createElement('div');
    title.className = 'title';
    title.textContent = m.title;

    const desc = document.createElement('div');
    desc.className = 'desc';
    desc.textContent = m.description || '';

    const actions = document.createElement('div');
    actions.className = 'row';
    const previewBtn = document.createElement('a');
    previewBtn.className = 'btn secondary';
    previewBtn.href = m.url;
    previewBtn.target = '_blank';
    previewBtn.rel = 'noopener';
    previewBtn.textContent = 'Preview';
    const dlBtn = document.createElement('a');
    dlBtn.className = 'btn';
    dlBtn.href = m.url;
    dlBtn.download = '';
    dlBtn.textContent = 'Download';
    actions.appendChild(previewBtn);
    actions.appendChild(dlBtn);

    card.appendChild(topRow);
    card.appendChild(title);
    card.appendChild(desc);
    card.appendChild(actions);
    grid.appendChild(card);
  });

  empty.hidden = filtered.length !== 0;
}

function populateFilters(){
  const cats = Array.from(new Set(materials.map(m=>m.category).filter(Boolean))).sort();
  const langs = Array.from(new Set(materials.map(m=>m.language).filter(Boolean))).sort();
  cats.forEach(c=>{ const o=document.createElement('option'); o.value=c; o.textContent=c; catSel.appendChild(o); });
  langs.forEach(l=>{ const o=document.createElement('option'); o.value=l; o.textContent=l.toUpperCase(); langSel.appendChild(o); });
}

async function init(){
  try{
    const res = await fetch('materials.json', {cache:'no-store'});
    materials = await res.json();
  }catch(e){
    console.error('Failed to load materials.json', e);
    materials = [];
  }
  populateFilters();
  render();
}

[search, catSel, langSel].forEach(el=>el.addEventListener('input', render));

init();
